import pojos.*;

import java.util.Calendar;

public class Main {

    private static Object Reseteable;

    public static void main(String[] args) {


        System.out.println("-----------INFORDATA------------");

        //definir el producto

        Producto producto = new Producto( "C0001" , "TECLADO GAMER");

        System.out.println(producto);

        System.out.println("\n");

        //definir alquiler

        Alquilar alquilar = new Alquilar("DGS040" , "MONITOR 27 PULG" , 10.4);

        System.out.println(alquilar);

        System.out.println("\n");

        //definir empresa

        Empresa empresa = new Empresa("LOS CACHIS CBBA" , "AV GABRIEL RENE MORENO" , 300  );

        System.out.println(empresa);

        System.out.println("\n");

        //definir productotecnologico

        Tecnologico tecnologico =  new Tecnologico("t3240" , "SSD HDATA" ,
                "EXPORTACIONES BOLIVIA-USA", Calendar.getInstance().getTime(), empresa);

        System.out.println(tecnologico);

        System.out.println("\n");

        //instanciando objet monitor

        Monitor monitor = new Monitor("JSE19203242" , "jala 27 pulgadas" , 16.8 , "1980x1080 FULL HD PAPA", null);

        System.out.println(monitor);

        System.out.println("\n");

        //cpu

        Empresa PCPLANET = new Empresa("PCPLANET" , "AV SANTACRUZ #234" , 5700 );

        Cpu cpu = new Cpu("JSE324524" , "AORUS" , " BOLIVIA EXPORTACIONES-USA" , Calendar.getInstance().getTime() , PCPLANET , 32, null);

        System.out.println(cpu);

        System.out.println("\n");

        //Reset valor/void no retorna ningun valor

        System.out.println("*****RESET*****");

        Reseteable reseteable = new Reseteable("0" , "TODOS LOS ANTERIORES" , 20 , null);

        System.out.println(Reseteable);



    }


}
